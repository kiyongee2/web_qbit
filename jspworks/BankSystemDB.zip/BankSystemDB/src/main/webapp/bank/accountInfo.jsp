<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
<title>계좌 정보</title> 
</head>
<body>
	<h2>계좌 정보</h2>
	계좌번호: ${account.accountNumber} <br>
	예금주: ${account.owner} <br>
	잔액: ${account.balance} 원 <br>
	
	<a href="/bank?action=depositForm">
		<button type="submit">입금</button>
	</a>
	<a href="/bank?action=withdrawForm">
		<button type="submit">출금</button>
	</a>
	
	<hr>
	<a href="bank?action=history&accountNumber=${account.accountNumber}">거래 내역 보기</a>
</body>
</html>
