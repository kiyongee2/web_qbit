package bankapp.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import bankapp.dto.BankAccount;
import bankapp.dto.Transaction;
import bankapp.service.BankAccountService;

@WebServlet("/bank")
public class BankAccountController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	BankAccountService service = new BankAccountService();
       
    public BankAccountController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        String nextPage = "";
        
        if(action.equals("accountForm")) { //계좌 개설 폼
        	nextPage = "/bank/accountForm.jsp";
        }else if(action.equals("create")){
        	String accountNumber = request.getParameter("accountNumber");
            String owner = request.getParameter("owner");

            try {
	            service.createAccount(accountNumber, owner);
	            request.setAttribute("account", service.getAccount(accountNumber));
	            nextPage = "/bank/accountInfo.jsp";
            }catch(IllegalArgumentException e) {
            	request.setAttribute("error", e.getMessage());
            }
        }else if(action.equals("searchForm")) {
        	nextPage = "/bank/searchForm.jsp";
        }else if(action.equals("info")) {
        	String accNum = request.getParameter("accountNumber");
        	request.setAttribute("account", service.getAccount(accNum));
        	nextPage = "/bank/accountInfo.jsp";
        }else if(action.equals("depositForm")) {
        	String accNum = request.getParameter("accountNumber");
        	request.setAttribute("account", service.getAccount(accNum));
        	nextPage = "/bank/depositForm.jsp";
        }else if(action.equals("deposit")) {
        	String accNum = request.getParameter("accountNumber");
        	int amount = Integer.parseInt(request.getParameter("amount"));
        	service.deposit(accNum, amount);
        	request.setAttribute("account", service.getAccount(accNum));
        	nextPage = "/bank/accountInfo.jsp";
        }else if(action.equals("withdrawForm")) {
        	String accNum = request.getParameter("accountNumber");
        	request.setAttribute("account", service.getAccount(accNum));
        	nextPage = "/bank/withdrawForm.jsp";
        }else if(action.equals("withdraw")) {
        	String accNum = request.getParameter("accountNumber");
        	int amount = Integer.parseInt(request.getParameter("amount"));
  
            try {
                service.withdraw(accNum, amount);
                request.setAttribute("account", service.getAccount(accNum));
                nextPage = "/bank/accountInfo.jsp";
            } catch (IllegalArgumentException e) {
                request.setAttribute("error", e.getMessage());
                nextPage = "/bank/withdraw.jsp";
            }
        }else if(action.equals("history")) {
        	String accNum = request.getParameter("accountNumber");
        	List<Transaction> list = service.getTransactions(accNum);
        	
        	request.setAttribute("transactions", list);
        	request.setAttribute("account", service.getAccount(accNum));
        	nextPage = "/bank/transactionHistory.jsp";
        }
        
        RequestDispatcher rd = request.getRequestDispatcher(nextPage);
        rd.forward(request, response);
	}

}
